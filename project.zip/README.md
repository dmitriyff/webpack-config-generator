## Setup
```bash
npm install
```

## Run development webserver
```bash
npm start
```

## Build production version
```bash
npm run build
```
